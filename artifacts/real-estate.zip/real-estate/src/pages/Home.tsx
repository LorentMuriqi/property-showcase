import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Search, Building2, Map, ShieldCheck } from "lucide-react";
import { Layout } from "@/components/Layout";
import { ProjectCard } from "@/components/ProjectCard";
import { supabase } from "@/lib/supabase";
import { Helmet } from "react-helmet-async";

const clearProjectsRestoreState = () => {
  sessionStorage.removeItem("projects-scroll-y");
  sessionStorage.removeItem("projects-return-url");
  sessionStorage.removeItem("projects-restore-scroll");
  sessionStorage.removeItem("projects-active-card-id");
  sessionStorage.removeItem("projects-active-card-top");
};

const prepareProjectsNavigationFromHome = () => {
  clearProjectsRestoreState();
  sessionStorage.removeItem("skip-global-scroll");
  sessionStorage.setItem("force-scroll-top", "1");
};

export default function Home() {
  const [, setLocation] = useLocation();
  const [country, setCountry] = useState("");
  const [city, setCity] = useState("");
  const [search, setSearch] = useState("");

  const [countries, setCountries] = useState<string[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  const [allFilterRows, setAllFilterRows] = useState<
    { country: string | null; city: string | null }[]
  >([]);
  const [recentProjects, setRecentProjects] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);




useEffect(() => {
  const fetchHomeData = async () => {
    setIsLoading(true);

    try {
      const nowIso = new Date().toISOString();

      const [filtersResult, recentProjectsResult] = await Promise.all([
        supabase
          .from("properties")
          .select("country, city")
          .eq("listing_status", "active")
          .eq("is_paused", false)
          .or(`expires_at.is.null,expires_at.gte.${nowIso}`),

        supabase
          .from("properties")
          .select(`
            id,
            title,
            description,
            country,
            city,
            address,
            status,
            property_type,
            price,
            currency,
            images,
            created_at,
            listing_status,
            is_paused,
            expires_at,
            virtual_tour_status,
            virtual_tour_url,
            virtual_tour_embed_code
          `)
          .eq("listing_status", "active")
          .eq("is_paused", false)
          .or(`expires_at.is.null,expires_at.gte.${nowIso}`)
          .order("created_at", { ascending: false })
          .limit(6),
      ]);

      if (filtersResult.error) {
        console.error("Fetch home filters error:", filtersResult.error);
        setAllFilterRows([]);
        setCountries([]);
        setCities([]);
      } else {
        const filterRows = filtersResult.data || [];

        setAllFilterRows(
          filterRows.map((item) => ({
            country: item.country ?? null,
            city: item.city ?? null,
          }))
        );

        const allCountries = [
          ...new Set(filterRows.map((item) => item.country).filter(Boolean)),
        ] as string[];

        setCountries(allCountries);
      }

      if (recentProjectsResult.error) {
        console.error("Fetch recent projects error:", recentProjectsResult.error);
        setRecentProjects([]);
        return;
      }

      const recentRows = recentProjectsResult.data || [];
      const propertyIds = recentRows.map((item) => item.id);

      let scenePropertyIds = new Set<string>();

      if (propertyIds.length > 0) {
        const { data: sceneRows, error: sceneError } = await supabase
          .from("virtual_tour_scenes")
          .select("property_id")
          .in("property_id", propertyIds);

        if (sceneError) {
          console.error("Fetch virtual tour scenes error:", sceneError);
        } else {
          scenePropertyIds = new Set(
            (sceneRows || []).map((scene) => String(scene.property_id))
          );
        }
      }

      const rowsWithVirtualTour = recentRows.map((item) => {
        const hasFallbackVirtualTour = !!(
          item.virtual_tour_url ||
          item.virtual_tour_embed_code
        );

        const hasPublishedBuiltInVirtualTour =
          item.virtual_tour_status === "published" &&
          scenePropertyIds.has(String(item.id));

        const hasVirtualTour =
          hasFallbackVirtualTour || hasPublishedBuiltInVirtualTour;

        return {
          ...item,
          hasVirtualTour,
        };
      });

      setRecentProjects(rowsWithVirtualTour);
    } finally {
      setIsLoading(false);
    }
  };

  fetchHomeData();
}, []);




  useEffect(() => {
    if (country) {
      const filteredCities = [
        ...new Set(
          allFilterRows
            .filter((item) => item.country === country)
            .map((item) => item.city)
            .filter(Boolean)
        ),
      ] as string[];

      setCities(filteredCities);
    } else {
      setCities([]);
    }
  }, [country, allFilterRows]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();

    prepareProjectsNavigationFromHome();

    const params = new URLSearchParams();
    if (country) params.append("country", country);
    if (city) params.append("city", city);
    if (search) params.append("search", search);

    setLocation(`/projects${params.toString() ? `?${params.toString()}` : ""}`);
  };

  return (
    <Layout>
      <section className="relative min-h-[90vh] flex items-center justify-center pt-20">
        <div className="absolute inset-0 z-0">
          <img
            src={`${import.meta.env.BASE_URL}images/hero-bg.png`}
            alt="Luxury Mansion"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-background/70 mix-blend-multiply" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 w-full text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
<h1 className="font-display text-5xl md:text-7xl font-bold text-white mb-6 leading-[1.15] md:leading-tight">
  <span className="block">Zbulo</span>
  <span className="block pb-1 text-gold-gradient italic">
    Pronën Tënde të Ëndrrave
  </span>
</h1>
<p className="text-base md:text-xl text-white/85 font-light mb-10 max-w-2xl mx-auto tracking-wide">
  Eksploro prona me ture virtuale 360°
</p>



<form
  onSubmit={handleSearch}
  className="max-w-5xl mx-auto rounded-[24px] bg-white/95 p-2 shadow-[0_24px_80px_rgba(0,0,0,0.28)] border border-white/30 backdrop-blur-xl flex flex-col md:flex-row gap-2 text-left"
>
  <div className="relative flex-1">
    <label className="absolute left-4 top-2 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground pointer-events-none">
      Shteti
    </label>

    <select
      className="w-full h-16 bg-transparent border border-border rounded-[18px] px-4 pt-7 pb-2 text-sm font-semibold text-foreground focus:outline-none focus:border-primary appearance-none cursor-pointer transition-colors"
      value={country}
      onChange={(e) => {
        setCountry(e.target.value);
        setCity("");
      }}
    >
      <option value="" className="bg-white text-foreground">
        Të gjitha shtetet
      </option>
      {countries.map((c) => (
        <option key={c} value={c} className="bg-white text-foreground">
          {c}
        </option>
      ))}
    </select>
  </div>

  <div className="relative flex-1">
    <label className="absolute left-4 top-2 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground pointer-events-none">
      Qyteti
    </label>

    <select
      className="w-full h-16 bg-transparent border border-border rounded-[18px] px-4 pt-7 pb-2 text-sm font-semibold text-foreground focus:outline-none focus:border-primary appearance-none cursor-pointer transition-colors disabled:opacity-45 disabled:cursor-not-allowed"
      value={city}
      onChange={(e) => setCity(e.target.value)}
      disabled={!country}
    >
      <option value="" className="bg-white text-foreground">
        Të gjitha qytetet
      </option>
      {cities.map((c) => (
        <option key={c} value={c} className="bg-white text-foreground">
          {c}
        </option>
      ))}
    </select>
  </div>

  <div className="relative flex-[1.4]">
    <label className="absolute left-12 top-2 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground pointer-events-none">
      Kërko
    </label>

    <Search
      className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground"
      size={19}
    />

    <input
      type="text"
      placeholder="Emri i pronës, adresë..."
      className="w-full h-16 bg-transparent border border-border rounded-[18px] pl-12 pr-4 pt-7 pb-2 text-sm font-semibold text-foreground placeholder:text-foreground/45 focus:outline-none focus:border-primary transition-colors"
      value={search}
      onChange={(e) => setSearch(e.target.value)}
    />
  </div>

  <button
    type="submit"
    className="w-full md:w-auto h-16 px-8 bg-primary text-primary-foreground font-bold tracking-widest uppercase text-sm rounded-[18px] hover:bg-primary/90 transition-colors"
  >
    Kërko
  </button>
</form>





          </motion.div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-10">
            <div className="text-center group">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-background border border-white/5 flex items-center justify-center text-primary group-hover:scale-110 group-hover:bg-primary group-hover:text-background transition-all duration-500">
                <Map size={32} strokeWidth={1.5} />
              </div>
              
<h3 className="font-display text-xl md:text-2xl text-foreground mb-2 font-bold">
  Ture Virtuale{" "}
  <span className="font-bold">
    360
    <span className="inline-block animate-spin-slow ml-[1px] text-primary/90">
      °
    </span>
  </span>
</h3>
			  
			  
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed max-w-sm mx-auto">
                Eksploroni çdo pronë në mënyrë reale përmes tureve 360°.
              </p>
            </div>
            <div className="text-center group">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-background border border-white/5 flex items-center justify-center text-primary group-hover:scale-110 group-hover:bg-primary group-hover:text-background transition-all duration-500">
                <Building2 size={32} strokeWidth={1.5} />
              </div>
              <h3 className="font-display text-xl md:text-2xl text-foreground mb-2 font-bold">Prona Ekskluzive</h3>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed max-w-sm mx-auto">
                Një përzgjedhje e kujdesshme e pronave më cilësore.
              </p>
            </div>
            <div className="text-center group">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-background border border-white/5 flex items-center justify-center text-primary group-hover:scale-110 group-hover:bg-primary group-hover:text-background transition-all duration-500">
                <ShieldCheck size={32} strokeWidth={1.5} />
              </div>
              <h3 className="font-display text-xl md:text-2xl text-foreground mb-2 font-bold">Shërbim i Klasit të Parë</h3>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed max-w-sm mx-auto">
                Mbështetje profesionale në çdo hap.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-10 md:mb-16 gap-6">
            <div>
              <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
                Pronat e Fundit
              </h2>
              <p className="text-muted-foreground text-lg max-w-xl">
                Eksploroni pronat tona më të fundit, të zgjedhura me kujdes për
                blerësit tanë.
              </p>
            </div>
            <Link
              href="/projects"
              onClick={() => {
                prepareProjectsNavigationFromHome();
              }}
              className="group flex items-center gap-2 text-primary font-medium tracking-widest uppercase text-sm hover:text-white transition-colors"
            >
              Shiko Të Gjitha Pronat
              <span className="w-8 h-[1px] bg-primary group-hover:bg-white transition-colors" />
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse bg-card rounded-2xl h-[400px]" />
              ))}
            </div>
          ) : recentProjects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {recentProjects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-card rounded-2xl border border-white/5">
              <p className="text-muted-foreground text-lg">
                Nuk ka projekte të veçuara aktualisht.
              </p>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}