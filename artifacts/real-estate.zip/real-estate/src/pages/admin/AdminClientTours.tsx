import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  ArrowLeft,
  Plus,
  Pause,
  Play,
  RefreshCw,
  Trash2,
  ExternalLink,
  Search,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";

type ClientTour = {
  id: string;
  title: string;
  client_name: string | null;
  status: "draft" | "active" | "paused" | "expired";
  client_token: string;
  expires_at: string | null;
  created_at: string;
};

function getComputedStatus(tour: ClientTour) {
  if (tour.status === "active" && tour.expires_at) {
    const expiresAt = new Date(tour.expires_at).getTime();
    if (Number.isFinite(expiresAt) && expiresAt < Date.now()) return "expired";
  }

  return tour.status;
}

function getStatusConfirmationMessage(
  tour: ClientTour,
  status: ClientTour["status"]
) {
  if (status === "active") {
    return `A dëshironi ta aktivizoni virtual tour-in "${tour.title}"?\n\nPas aktivizimit, linku publik do të jetë i qasshëm për klientin.`;
  }

  if (status === "paused") {
    return `A dëshironi ta pezulloni virtual tour-in "${tour.title}"?\n\nPas pezullimit, linku publik nuk do të jetë aktiv derisa ta aktivizoni përsëri.`;
  }

  if (status === "draft") {
    return `A dëshironi ta ktheni virtual tour-in "${tour.title}" në Draft?\n\nPas kthimit në Draft, turi nuk do të jetë aktiv për klientin.`;
  }

  return `A dëshironi ta ndryshoni statusin e virtual tour-it "${tour.title}"?`;
}

export default function AdminClientTours() {
  const { isAdmin, permissions, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

const [tours, setTours] = useState<ClientTour[]>([]);
const [isLoading, setIsLoading] = useState(true);

const [searchQuery, setSearchQuery] = useState("");
const [page, setPage] = useState(1);
const pageSize = 20;

  useEffect(() => {
    if (authLoading) return;

    if (!isAdmin) {
      setLocation("/admin/login");
      return;
    }

    if (!permissions.canManageVirtualTours) {
      setLocation("/admin");
    }
  }, [authLoading, isAdmin, permissions, setLocation]);


const fetchTours = async (options?: { silent?: boolean; preserveScroll?: boolean }) => {
  const savedScrollY = options?.preserveScroll ? window.scrollY : null;

  if (!options?.silent) {
    setIsLoading(true);
  }

  const { data, error } = await supabase
    .from("virtual_tours")
    .select("id, title, client_name, status, client_token, expires_at, created_at")
    .eq("visibility", "client_only")
    .order("created_at", { ascending: false });

  if (error) {
    toast({
      title: "Gabim",
      description: "Nuk u ngarkuan virtual tours.",
      variant: "destructive",
    });
    setTours([]);
  } else {
    setTours((data || []) as ClientTour[]);
  }

  setIsLoading(false);

  if (savedScrollY !== null) {
    requestAnimationFrame(() => {
      window.scrollTo({
        top: savedScrollY,
        left: 0,
        behavior: "auto",
      });
    });
  }
};


  useEffect(() => {
    if (!authLoading && isAdmin && permissions.canManageVirtualTours) {
      fetchTours();
    }
  }, [authLoading, isAdmin, permissions.canManageVirtualTours]);

  const createTour = async () => {
    const title = prompt("Emri i virtual tour-it, p.sh. Hotel Dukagjini");
    if (!title?.trim()) return;

    const clientName = prompt("Emri i klientit / kompanisë (opsionale)") || null;

    const { data, error } = await supabase
      .from("virtual_tours")
      .insert({
        title: title.trim(),
        client_name: clientName,
        status: "draft",
        visibility: "client_only",
      })
      .select("id")
      .single();

    if (error || !data) {
      toast({
        title: "Gabim",
        description: error?.message || "Virtual tour nuk u krijua.",
        variant: "destructive",
      });
      return;
    }

    setLocation(`/admin/client-tours/${data.id}/virtual-tour`);
  };

  
  const updateStatus = async (tour: ClientTour, status: ClientTour["status"]) => {
  const confirmed = window.confirm(getStatusConfirmationMessage(tour, status));

  if (!confirmed) return;

  const nowIso = new Date().toISOString();

  const payload: Partial<{
    status: ClientTour["status"];
    paused_at: string | null;
    activated_at: string | null;
    updated_at: string;
  }> = {
    status,
    updated_at: nowIso,
  };

  if (status === "paused") {
    payload.paused_at = nowIso;
  }

  if (status === "active") {
    payload.activated_at = nowIso;
    payload.paused_at = null;
  }

  if (status === "draft") {
    payload.paused_at = null;
  }

  const { error } = await supabase
    .from("virtual_tours")
    .update(payload)
    .eq("id", tour.id);

  if (error) {
    toast({
      title: "Gabim",
      description: error.message,
      variant: "destructive",
    });
    return;
  }

  toast({
    title: "Sukses",
    description:
      status === "active"
        ? "Virtual tour u aktivizua."
        : status === "paused"
          ? "Virtual tour u pezullua."
          : "Virtual tour u kthye në Draft.",
  });

  fetchTours({ silent: true, preserveScroll: true });
};
  

  const deleteTour = async (tour: ClientTour) => {
    if (!confirm(`A dëshironi ta fshini "${tour.title}"?`)) return;

    const { error } = await supabase.from("virtual_tours").delete().eq("id", tour.id);

    if (error) {
      toast({
        title: "Gabim",
        description: error.message,
        variant: "destructive",
      });
      return;
    }

    fetchTours({ silent: true, preserveScroll: true });
  };
  
  const filteredTours = tours.filter((tour) => {
  const normalizedSearch = searchQuery.trim().toLowerCase();

  if (!normalizedSearch) return true;

  const computedStatus = getComputedStatus(tour);

  return (
    String(tour.title || "").toLowerCase().includes(normalizedSearch) ||
    String(tour.client_name || "").toLowerCase().includes(normalizedSearch) ||
    String(computedStatus || "").toLowerCase().includes(normalizedSearch)
  );
});

const totalPages = Math.max(1, Math.ceil(filteredTours.length / pageSize));
const safePage = Math.min(page, totalPages);

const paginatedTours = filteredTours.slice(
  (safePage - 1) * pageSize,
  safePage * pageSize
);

useEffect(() => {
  setPage(1);
}, [searchQuery]);

  const appOrigin = typeof window !== "undefined" ? window.location.origin : "";

  if (authLoading || isLoading) {
    return <div className="min-h-screen bg-background" />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground pb-24">
      <div className="sticky top-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border p-4 md:p-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setLocation("/admin")}
            className="w-10 h-10 rounded-full bg-muted hover:bg-muted/80 flex items-center justify-center"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="font-display text-2xl font-bold leading-none">
              Client Virtual Tours
            </h1>
            <p className="text-muted-foreground text-xs uppercase tracking-widest mt-1">
              Ture private për hotele, biznese dhe klientë
            </p>
          </div>
        </div>

        <button
          onClick={createTour}
          className="px-5 py-3 rounded-xl bg-primary text-black font-bold text-sm inline-flex items-center gap-2"
        >
          <Plus size={16} />
          Virtual Tour i Ri
        </button>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 mt-8">
        <div className="glass-panel rounded-2xl border border-border overflow-hidden">
<div className="p-6 border-b border-border space-y-4">
  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
    <div>
      <h2 className="font-display text-xl">Lista e tureve private</h2>
      <p className="text-sm text-muted-foreground mt-1">
        {filteredTours.length}{" "}
        {filteredTours.length === 1 ? "tur u gjet" : "ture u gjetën"}
      </p>
    </div>

    <div className="relative w-full md:w-80">
      <Search
        size={17}
        className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
      />
      <input
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        placeholder="Kërko sipas emrit ose klientit..."
        className="w-full bg-background border border-border rounded-xl pl-10 pr-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
      />
    </div>
  </div>
</div>

          <div className="divide-y divide-border">
            {paginatedTours.map((tour) => {
              const computedStatus = getComputedStatus(tour);
              const publicUrl = `${appOrigin}/client-tour/${tour.client_token}`;

              return (
                <div key={tour.id} className="p-5 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  <div>
                    <h3 className="font-semibold text-foreground">{tour.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {tour.client_name || "Pa klient"} ·{" "}
                      {tour.expires_at
                        ? `Skadon më ${new Date(tour.expires_at).toLocaleDateString("sq-AL")}`
                        : "Pa datë skadimi"}
                    </p>

                    <div className="flex flex-wrap gap-2 mt-3">
                      <span className={`px-2 py-1 rounded-full text-xs border ${
                        computedStatus === "active"
                          ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/30"
                          : computedStatus === "paused"
                          ? "bg-yellow-500/10 text-yellow-500 border-yellow-500/30"
                          : computedStatus === "expired"
                          ? "bg-red-500/10 text-red-400 border-red-500/30"
                          : "bg-muted text-muted-foreground border-border"
                      }`}>
                        {computedStatus}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Link href={`/admin/client-tours/${tour.id}/virtual-tour`}>
                      <button className="px-4 py-2 rounded-xl bg-primary/10 text-primary font-semibold">
                        Edito Turin
                      </button>
                    </Link>

                    <a href={publicUrl} target="_blank" rel="noreferrer">
                      <button className="px-4 py-2 rounded-xl bg-muted text-foreground inline-flex items-center gap-2">
                        <ExternalLink size={14} />
                        Hap Linkun
                      </button>
                    </a>

                    {computedStatus !== "active" && (
                      <button
                        onClick={() => updateStatus(tour, "active")}
                        className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500"
                        title="Aktivizo"
                      >
                        <Play size={16} />
                      </button>
                    )}

                    {computedStatus === "active" && (
                      <button
                        onClick={() => updateStatus(tour, "paused")}
                        className="p-2 rounded-xl bg-yellow-500/10 text-yellow-500"
                        title="Pezullo"
                      >
                        <Pause size={16} />
                      </button>
                    )}

                    {computedStatus !== "draft" && (
                      <button
                        onClick={() => updateStatus(tour, "draft")}
                        className="p-2 rounded-xl bg-muted text-foreground"
                        title="Kthe në Draft"
                      >
                        <RefreshCw size={16} />
                      </button>
                    )}

                    <button
                      onClick={() => deleteTour(tour)}
                      className="p-2 rounded-xl bg-red-500/10 text-red-400"
                      title="Fshi"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              );
            })}

            {filteredTours.length === 0 && (
              <div className="p-8 text-center text-muted-foreground">
                {searchQuery.trim()
                  ? "Nuk u gjet asnjë virtual tour me këtë kërkim."
                  : "Nuk ka virtual tours ende."}
              </div>
            )}
          </div>

          {filteredTours.length > pageSize && (
            <div className="p-5 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="text-sm text-muted-foreground">
                Duke shfaqur {(safePage - 1) * pageSize + 1}–
                {Math.min(safePage * pageSize, filteredTours.length)} nga{" "}
                {filteredTours.length}
              </p>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setPage((prev) => Math.max(1, prev - 1))}
                  disabled={safePage === 1}
                  className="px-4 py-2 rounded-xl border border-border text-foreground disabled:opacity-40 disabled:cursor-not-allowed hover:border-primary transition-colors"
                >
                  Mbrapa
                </button>

                <span className="px-4 py-2 rounded-xl bg-muted text-sm text-foreground">
                  {safePage} / {totalPages}
                </span>

                <button
                  type="button"
                  onClick={() => setPage((prev) => Math.min(totalPages, prev + 1))}
                  disabled={safePage === totalPages}
                  className="px-4 py-2 rounded-xl border border-border text-foreground disabled:opacity-40 disabled:cursor-not-allowed hover:border-primary transition-colors"
                >
                  Para
                </button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}